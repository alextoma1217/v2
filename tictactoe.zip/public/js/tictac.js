'use strict';
const cell = document.getElementsByClassName('tictactoe_cell'); 
const message = document.getElementById('message');
const player1 = document.getElementById('player1');
const player2 = document.getElementById('player2');
const spectators = document.getElementById('spectators');
const clocks = document.getElementById('countdown_input');
const prompt_tictactoe = document.getElementById('prompt_tictactoe');
const user_id = document.getElementById('user_id').innerText.trim();
let player1_id, player2_id, player1_name, player2_name, game_room;
let player_number =3;
let player_turn =1;
let player = 'X';
let  winnings = [ [1, 2, 3],  [1, 4, 7],  [1, 5, 9], [2, 5, 8],  [3, 6, 9], [3, 5, 7], [4, 5, 6], [7, 8, 9] ];
  let positionX = [];
  let positionO = [];
  let num;
  let movesAmount = 0;
const socket = io();
function clickCells(){
    if(player_number === player_turn ){
     for (let i = 0; i < cell.length; i++) {  
    cell[i].addEventListener('click', getEventData);
    } 
  }
  else{
    for (let i = 0; i < cell.length; i++) {  
    cell[i].removeEventListener('click', getEventData);
    } 
  }
}
function getEventData(){
  let num = +this.getAttribute('data-cell');
  let in_array = false;
  if(positionX.length>0){
    if(positionX.indexOf(num)!== -1){
      message.innerText = 'This cell is already occupied by X';
      return false;
    }
  }

    if(positionO.length>0){
    if(positionO.indexOf(num)!== -1){
      message.innerText = 'This cell is already occupied by O';
      return false;
    }
  }

  let current_turn = 1;
  if(player_turn==1){
    current_turn=2;
  }

  socket.emit('newTictacToeData', {game_room, num, player_number, current_turn});
}
function changePlayer() {
  player_turn === 1 ? (player_turn = 2) : (player_turn = 1); 
   clickCells();      
}
function finishGame(){
  clearInterval(clocktimer);
 socket.emit('finishTicTacToe', game_room);
    setTimeout(function () {
     window.location ='/dashboard';
    }, 2000);
}

function updateGameField(positionX, positionO){
   if(positionX.length>0){
    for (let i = 0; i < cell.length; i++) {
       for(let a =0; a<positionX.length; a++){
        let number = cell[i].getAttribute('data-cell');
        if(number == positionX[a]){       
        cell[i].innerText = 'X';
        cell[i].classList.add('x');        
        }
       }
      }
    }
    if(positionO.length>0){
     for (let i = 0; i < cell.length; i++) {
       for(let a =0; a<positionO.length; a++){
        let number = cell[i].getAttribute('data-cell');
        if(number == positionO[a]){
        cell[i].classList.add('o');
        cell[i].innerText = 'O';
        }
       }
      }
   }
 }

function checkWin(arr, number) {
  for (let w = 0, wLen = winnings.length; w < wLen; w++) {
    let actulArray = winnings[w],
      count = 0;
    if (actulArray.indexOf(number) !== -1) {
      for (let k = 0, kLen = actulArray.length; k < kLen; k++) {
        if (arr.indexOf(actulArray[k]) !== -1) {
          count++;
          if (count === 3) {
            return true;
          }
        }
      }
      count = 0;
    }
  }
}

function trim(string) { 
   return string.replace (/\s+/g, " ").replace(/(^\s*)|(\s*)$/g, '');
    }

 let init=0;
 let startDate;
 let clocktimer;

 function clearFields() {
  init = 0;
  clearTimeout(clocktimer);
  clocks.value='00:00:00';  
 }

 function clearALL() {
  clearFields();
 }

 function startCountDown() { 
  let thisDate = new Date();
  let t = thisDate.getTime() - startDate.getTime();
  let ms = t%1000; 
  t-=ms; 
  t = Math.floor (t/1000);
  let s = t%60; t-=s;
  t = Math.floor (t/60);
  let m = t%60; t-=m;
  t = Math.floor (t/60);
  let h = t%60;
  if (h<10) {
    h ='0'+h; 
   }
  if (m<10) {
    m ='0'+m; 
   }
  if (s<10) {
    s ='0'+s; 
   }

  if (init==1) {
    clocks.value = h + ':' + m + ':' + s;
  }
  clocktimer = setTimeout('startCountDown()',1000);
 }

 function findTimer() {
  if (init==0) {
   startDate = new Date();
    startCountDown();
   init=1;
  } 
 }
window.addEventListener('load', function() {
  const searchString = new URLSearchParams(window.location.search);
  let params = [];
  searchString.forEach((value) => {
  params.push(value); 
});

game_room = params[0];
  socket.emit('getGameData', { user_id, game_room});
});

// Listen for chatMessage
  socket.on('gameInitialData', data => {
    if(data.data[0].length>0){
       player1_id = data.data[0][0].id; 
       if(player1_id == user_id){
        player_number =1;
      }
      player1_name = data.data[0][0].name;
      player1.innerText = player1_name;
    }
     if(data.data[1].length>0){
       player2_id = data.data[1][0].id; 
       if(player2_id == user_id){
           player_number =2;
        }
       player2_name = data.data[1][0].name;
       player2.innerText = player2_name;
    }
   
   if(player1_id && player2_id){
                 if(player_number === 1 || player_number === 2){
                    if(player_number!==player_turn){            
                     message.innerText = "It's your opponents move";
                    }
                    else if(player_number==player_turn){
                     message.innerText = 'Your move!'; 
                    }
                   }

             else if(player_number ===3){
                 message.innerText = 'Next move player: ' + player_turn;
             }

             if(data.data[5].length>0){
              player_turn = data.data[5]; 
             }            
           

     clickCells();
     findTimer();
   }

   else{
      message.innerText = 'Waiting for 2 players...';

   }

   if(data.data[2].length>0){
     spectators.innerText = data.data[2].length;
   }

      if(data.data[3].length>0){
         positionX = data.data[3];
      }

      if(data.data[4].length>0){
          positionO = data.data[4];
      }
      updateGameField(positionX, positionO);
      movesAmount = positionX.length+ positionO.length;

  });


// Listen for chatMessage
  socket.on('gameUpdate', data => {
    positionX = data.newdataX;
    positionO = data.newdataO;
    num = data.number;
     updateGameField(positionX, positionO);
     movesAmount = positionX.length+ positionO.length;

      if (
      (positionO.length > 2 || positionX.length > 2) &&
      (checkWin(positionO, num) || checkWin(positionX, num))
    ) 
    {

      message.innerText = 'This game is finished! Player ' + player_turn +  ' is a winner.';
      finishGame();
      return;

    }
    else{
    changePlayer();
    movesAmount++;

    if(movesAmount ===9){
      message.innerText = 'The game ended in a draw';
        finishGame();
        return;
    }
    else{
      if(player_number ===1 || player_number === 2){
        if(player_turn === player_number){
          message.innerText = 'Your move!' ;
        }
        else{
          message.innerText = 'Player move ' + player_turn;
        }
      }
      else{
        message.innerText = 'Player move ' + player_turn;
      }      
    }
  }
});

socket.on('updateSpectators', spectators_amount => {
   spectators.innerText = spectators_amount;
}); 


socket.on('winnerOnDisconnect', winner => {
   message.innerHTML = `One player has left the room... 
   The game is finished! Player  ${winner}  is a winner`;
   setTimeout(function () {
     window.location ='/dashboard';
    }, 2000);
});   

socket.on('disconnectNotStarted', winner => {
   message.innerHTML = 'This game is finished....';
   setTimeout(function () {
     window.location ='/dashboard';
    }, 2000);
});  
