dbPassword = 'mongodb+srv://walkeradmin:Vari12*kasdfg@cluster0.gh8vk.mongodb.net/myFirstDatabase?retryWrites=true&w=majority';

module.exports = {
    mongoURI: dbPassword
};


// dbPassword  = 'mongodb://localhost/tictactoe';

// module.exports = {
//     mongoURI: dbPassword
// };

module.exports = {
    mongoURI: dbPassword
};