class TictactoePlayer {
	constructor(socketid, room, user_id) {
		this.socketid = socketid;
		this.room = room;
		this.userid = user_id;
	}

}

module.exports = TictactoePlayer;